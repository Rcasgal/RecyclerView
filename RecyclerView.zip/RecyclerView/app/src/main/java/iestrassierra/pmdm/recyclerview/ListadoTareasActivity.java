package iestrassierra.pmdm.recyclerview;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class ListadoTareasActivity extends AppCompatActivity {

    private RecyclerView recyclerViewTareas;
    private TextView textViewNoTareas;
    private TareaAdapter tareaAdapter;
    private List<Tarea> listaTareas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado_tareas);

        recyclerViewTareas = findViewById(R.id.recyclerViewTareas);
        textViewNoTareas = findViewById(R.id.textViewNoTareas);
        Calendar fechaTarea1 = new GregorianCalendar(2024, Calendar.MAY, 3);

        Calendar fechaTarea2 = new GregorianCalendar(2024, Calendar.AUGUST, 25);

        Date fechaTarea1Date = fechaTarea1.getTime();
        Date fechaTarea2Date = fechaTarea2.getTime();
        listaTareas = new ArrayList<>();
        listaTareas.add(new Tarea("Tarea 1", "Descripción de la Tarea 1", 50, new Date(), fechaTarea1Date, true));
        listaTareas.add(new Tarea("Tarea 2", "Descripción de la Tarea 2", 1, new Date(), fechaTarea2Date, false));

        recyclerViewTareas.setLayoutManager(new LinearLayoutManager(this));
        tareaAdapter = new TareaAdapter(listaTareas);
        recyclerViewTareas.setAdapter(tareaAdapter);

        if (tareaAdapter.getItemCount() == 0) {
            recyclerViewTareas.setVisibility(View.GONE);
            textViewNoTareas.setVisibility(View.VISIBLE);
        } else {
            recyclerViewTareas.setVisibility(View.VISIBLE);
            textViewNoTareas.setVisibility(View.GONE);
        }
    }
}